import os
import json
import logging
import sys
from pathlib import Path
from datetime import datetime, timezone

from dotenv import load_dotenv
from fastapi import FastAPI, Request, Body
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

from finance_engine import (
    calculate_dre, calculate_cash_flow, calculate_break_even,
    calculate_operational_cycle, calculate_financial_cycle, calculate_minimum_cash,
)
from finance_engine.audit import log as audit_log

from siberian_connector import client as siberian_client
from siberian_connector.routes import router as siberian_router

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("tokyoos")

BASE_DIR = Path(__file__).parent
CONFIG_DIR = BASE_DIR / "config"
INTERFACE_DIR = BASE_DIR / "interface"
DOCS_DIR = BASE_DIR / "docs"

TOKYO_ENV = os.getenv("TOKYO_ENV", "zimaos")
TOKYO_HOST = os.getenv("TOKYO_HOST", "0.0.0.0")
TOKYO_HTTP_PORT = int(os.getenv("TOKYO_HTTP_PORT", "8788"))
TOKYO_SAFE_MODE = os.getenv("TOKYO_SAFE_MODE", "true").lower() == "true"
TOKYO_TOKEN_EXPOSED = os.getenv("TOKYO_TOKEN_EXPOSED", "false").lower() == "true"

app = FastAPI(
    title="TokyoOS",
    description="Tokyo IA - GrupsBunny AI Hub — Phase 3C ZimaOS Ready",
    version="3.2.0-phase3c",
    docs_url="/tokyo/docs",
    redoc_url="/tokyo/redoc",
)

app.include_router(siberian_router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def load_json_config(filename):
    path = CONFIG_DIR / filename
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return None


def safe_response(data):
    data["_meta"] = {
        "token_exposed": TOKYO_TOKEN_EXPOSED,
        "safe_mode": TOKYO_SAFE_MODE,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "tokyo_version": "3.2.0-phase3c",
        "status": "SAFE_TO_CONTINUE_PHASE_3C_ZIMAOS_READY",
    }
    return JSONResponse(content=data)


def env_bool(name, default=False):
    return os.getenv(name, str(default).lower()).lower() in ("true", "1", "yes")


def env_present(name):
    val = os.getenv(name, "")
    return len(val) > 0


def mask_secret(val):
    if not val:
        return ""
    return val[:4] + "***" if len(val) > 8 else "***"


@app.get("/", response_class=HTMLResponse)
@app.get("/ui", response_class=HTMLResponse)
@app.get("/ui/", response_class=HTMLResponse)
async def serve_ui():
    ui_file = INTERFACE_DIR / "index.html"
    if ui_file.exists():
        return HTMLResponse(content=ui_file.read_text(encoding="utf-8"))
    return HTMLResponse(content="<h1>TokyoOS UI not found</h1>", status_code=404)


@app.get("/tokyo/system/health")
async def system_health():
    return safe_response({
        "health": "ok",
        "environment": TOKYO_ENV,
        "uptime": "active",
        "voice_preserved": True,
        "app_preserved": True,
        "safe_mode": TOKYO_SAFE_MODE,
    })


@app.get("/tokyo/setup/status")
async def setup_status():
    return safe_response({
        "setup_complete": False,
        "wizard_available": True,
        "first_config_done": False,
        "env_validated": bool(load_dotenv()),
        "credentials_checked": False,
        "integrations_checked": False,
        "providers_checked": False,
        "steps": {
            "env_validation": "pending_first_run",
            "credentials_status": "pending",
            "integrations_status": "pending",
            "providers_status": "pending",
            "storage_check": "pending",
            "voice_check": "pending",
            "security_check": "pending",
            "docker_readiness": "pending",
        },
    })


@app.get("/tokyo/setup/checklist")
async def setup_checklist():
    return safe_response({
        "checklist": [
            {"id": "env_file", "label": ".env configurado", "status": "pending", "detail": "Configure as variaveis no .env"},
            {"id": "gemini_key", "label": "Gemini API Key", "status": "configured" if env_present("GEMINI_API_KEY") else "not_configured", "detail": "Motor LLM principal recomendado"},
            {"id": "openai_key", "label": "OpenAI API Key", "status": "configured" if env_present("OPENAI_API_KEY") else "not_configured", "detail": "Motor LLM fallback"},
            {"id": "livekit", "label": "LiveKit Voice", "status": "configured" if env_present("LIVEKIT_URL") else "not_configured", "detail": "Voz oficial Tokyo"},
            {"id": "memory", "label": "Memoria (Mem0/Local)", "status": "configured" if env_present("MEM0_API_KEY") else "configured_local", "detail": "Memoria da Tokyo"},
            {"id": "siberian", "label": "Sistema Siberian ERP", "status": "not_configured", "detail": "ERP proprio do GrupsBunny"},
            {"id": "security", "label": "Seguranca", "status": "configured" if TOKYO_SAFE_MODE else "not_configured", "detail": "Safe mode ativo"},
            {"id": "docker", "label": "Docker/ZimaOS", "status": "pending", "detail": "Preparar para deploy 24/7"},
        ],
    })


@app.get("/tokyo/doctor")
async def doctor():
    return safe_response({
        "status": "healthy_with_pending_items",
        "checks": {
            "system": {"status": "healthy", "detail": "TokyoOS rodando"},
            "ui": {"status": "healthy", "detail": "Interface disponivel"},
            "voice": {"status": "healthy" if env_present("LIVEKIT_URL") else "not_configured", "detail": "LiveKit voice agent"},
            "gemini": {"status": "configured" if env_present("GEMINI_API_KEY") else "not_configured", "detail": "Google Gemini provider"},
            "openai": {"status": "configured" if env_present("OPENAI_API_KEY") else "not_configured", "detail": "OpenAI provider"},
            "memory": {"status": "healthy", "detail": "Local memory enabled"},
            "mem0": {"status": "configured" if env_present("MEM0_API_KEY") else "not_configured", "detail": "Mem0 cloud memory"},
            "storage": {"status": "healthy", "detail": "Local storage ok"},
            "security": {"status": "secure" if TOKYO_SAFE_MODE else "warning", "detail": "Safe mode " + ("enabled" if TOKYO_SAFE_MODE else "disabled")},
            "docker": {"status": "pending", "detail": "Docker/ZimaOS deployment pending"},
            "siberian": {"status": "not_configured", "detail": "Sistema Siberian not connected"},
            "integrations": {"status": "pending", "detail": "Optional integrations not configured"},
        },
        "recommendations": [
            "Configurar GEMINI_API_KEY para LLM principal",
            "Configurar LIVEKIT_URL para voz",
            "Sistema Siberian nao requer configuracao nesta fase",
            "Integracoes opcionais (Hermes, MCP, Ollama) nao sao obrigatorias",
        ],
    })


@app.get("/tokyo/llm/status")
async def llm_status():
    providers_config = load_json_config("providers.example.json")
    return safe_response({
        "default_provider": os.getenv("TOKYO_DEFAULT_LLM_PROVIDER", "gemini"),
        "fallback_provider": os.getenv("TOKYO_FALLBACK_LLM_PROVIDER", "openai"),
        "providers": {
            "gemini": {
                "configured": env_present("GEMINI_API_KEY"),
                "model": os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
                "status": "configured" if env_present("GEMINI_API_KEY") else "not_configured",
                "voice_support": True,
                "realtime_support": True,
            },
            "openai": {
                "configured": env_present("OPENAI_API_KEY"),
                "model": os.getenv("OPENAI_MODEL", "gpt-4o"),
                "status": "configured" if env_present("OPENAI_API_KEY") else "not_configured",
                "voice_support": True,
                "realtime_support": False,
            },
            "openai_compatible": {
                "configured": env_present("OPENAI_COMPATIBLE_BASE_URL"),
                "model": os.getenv("OPENAI_COMPATIBLE_MODEL", ""),
                "status": "configured" if env_present("OPENAI_COMPATIBLE_BASE_URL") else "not_configured",
            },
            "ollama": {
                "configured": env_present("OLLAMA_BASE_URL"),
                "status": "configured" if env_present("OLLAMA_BASE_URL") else "not_configured",
                "required": False,
                "mode": "optional",
            },
            "openwebui": {
                "configured": env_present("OPENWEBUI_BASE_URL"),
                "status": "configured" if env_present("OPENWEBUI_BASE_URL") else "not_configured",
                "required": False,
                "mode": "optional",
            },
        },
        "token_exposed": TOKYO_TOKEN_EXPOSED,
        "voice_preserved": True,
    })


@app.get("/tokyo/providers/registry")
async def providers_registry():
    config = load_json_config("providers.example.json")
    if config:
        return safe_response(config)
    return safe_response({"error": "Providers config not found", "providers": []})


@app.get("/tokyo/providers/status")
async def providers_status():
    return safe_response({
        "providers": [
            {"id": "gemini", "configured": env_present("GEMINI_API_KEY"), "status": "configured" if env_present("GEMINI_API_KEY") else "not_configured"},
            {"id": "openai", "configured": env_present("OPENAI_API_KEY"), "status": "configured" if env_present("OPENAI_API_KEY") else "not_configured"},
            {"id": "openai_compatible", "configured": env_present("OPENAI_COMPATIBLE_BASE_URL"), "status": "configured" if env_present("OPENAI_COMPATIBLE_BASE_URL") else "not_configured"},
            {"id": "ollama", "configured": env_present("OLLAMA_BASE_URL"), "required": False, "status": "configured" if env_present("OLLAMA_BASE_URL") else "not_configured"},
            {"id": "openwebui", "configured": env_present("OPENWEBUI_BASE_URL"), "required": False, "status": "configured" if env_present("OPENWEBUI_BASE_URL") else "not_configured"},
        ],
    })


@app.get("/tokyo/integrations/registry")
async def integrations_registry():
    config = load_json_config("integrations.example.json")
    if config:
        return safe_response(config)
    return safe_response({"error": "Integrations config not found", "integrations": []})


@app.get("/tokyo/integrations/status")
async def integrations_status():
    config = load_json_config("integrations.example.json")
    overview = []
    if config:
        for integration in config.get("integrations", []):
            item = {
                "id": integration["id"],
                "name": integration["name"],
                "category": integration["category"],
                "required": integration.get("required", False),
                "status": integration.get("status", "not_configured"),
                "mode": integration.get("mode", "optional"),
            }
            overview.append(item)
    return safe_response({
        "integrations": overview,
        "total": len(overview),
        "configured": sum(1 for i in overview if i["status"] == "configured"),
        "total_required": sum(1 for i in overview if i.get("required", False)),
    })


@app.get("/tokyo/connectors/registry")
async def connectors_registry():
    config = load_json_config("connectors.example.json")
    if config:
        return safe_response(config)
    return safe_response({"error": "Connectors config not found", "connectors": []})


@app.get("/tokyo/plugins/registry")
async def plugins_registry():
    return safe_response({
        "plugins": [],
        "connectors": True,
        "api_hub": True,
        "message": "Plugins use same registry as connectors. See /tokyo/connectors/registry",
    })


@app.get("/tokyo/api-hub/status")
async def api_hub_status():
    return safe_response({
        "api_hub": "Tokyo API Hub",
        "status": "active",
        "description": "Central para conectar APIs externas",
        "principle": "Cada ferramenta tem endpoint/base_url/token_env. Falha de ferramenta opcional nao derruba a TokyoOS.",
        "endpoints_available": [
            "/tokyo/system/health",
            "/tokyo/setup/status",
            "/tokyo/setup/checklist",
            "/tokyo/doctor",
            "/tokyo/llm/status",
            "/tokyo/providers/registry",
            "/tokyo/providers/status",
            "/tokyo/integrations/registry",
            "/tokyo/integrations/status",
            "/tokyo/connectors/registry",
            "/tokyo/plugins/registry",
            "/tokyo/api-hub/status",
            "/tokyo/mcp/status",
            "/tokyo/memory/status",
            "/tokyo/voice/status",
            "/tokyo/security/status",
            "/tokyo/business/status",
            "/tokyo/grupsbunny/status",
            "/tokyo/bunnydreams/status",
            "/tokyo/bunnysiberian/status",
            "/tokyo/siberian/status",
            "/tokyo/finance/status",
            "/tokyo/finance/models",
            "/tokyo/finance/references",
        ],
        "token_exposed": TOKYO_TOKEN_EXPOSED,
    })


@app.get("/tokyo/mcp/status")
async def mcp_status():
    return safe_response({
        "mcp": {
            "enabled": env_bool("MCP_ENABLED"),
            "required": False,
            "status": "configured" if env_present("MCP_BASE_URL") else "not_configured",
            "mode": "optional",
            "safe_mode": True,
            "default_port": 8789,
            "base_url_configured": env_present("MCP_BASE_URL"),
            "api_key_configured": env_present("MCP_API_KEY"),
            "message": "MCP entra como conector opcional. Nao e core da TokyoOS.",
        }
    })


@app.get("/tokyo/memory/status")
async def memory_status():
    return safe_response({
        "memory": {
            "mem0": {
                "enabled": env_bool("MEM0_ENABLED", True),
                "configured": env_present("MEM0_API_KEY"),
                "status": "configured" if env_present("MEM0_API_KEY") else "not_configured",
                "type": "cloud_memory",
            },
            "obsidian": {
                "enabled": env_bool("OBSIDIAN_ENABLED"),
                "configured": env_present("OBSIDIAN_API_KEY"),
                "status": "configured" if env_present("OBSIDIAN_API_KEY") else "not_configured",
                "vault_path": os.getenv("OBSIDIAN_VAULT_PATH", "/data/tokyo/memory/obsidian"),
                "type": "local_vault",
            },
            "local_memory": {
                "enabled": env_bool("LOCAL_MEMORY_ENABLED", True),
                "status": "configured",
                "path": os.getenv("LOCAL_MEMORY_PATH", "/data/tokyo/memory/local"),
                "type": "local_filesystem",
            },
            "bunny_intelligence": {
                "enabled": env_bool("BUNNY_INTELLIGENCE_ENABLED", True),
                "status": "configured",
                "path": os.getenv("BUNNY_INTELLIGENCE_PATH", "/data/tokyo/intelligence"),
                "type": "document_bank",
            },
        },
        "voice_memory_preserved": True,
        "message": "Mem0 esta integrado ao agente de voz. Memorias preservadas.",
    })


@app.get("/tokyo/voice/status")
async def voice_status():
    return safe_response({
        "voice": {
            "status": "active",
            "provider": "LiveKit",
            "llm": "Google Gemini Realtime",
            "voice_name": "Charon",
            "configured": env_present("LIVEKIT_URL"),
            "livekit_url_configured": env_present("LIVEKIT_URL"),
            "livekit_key_configured": env_present("LIVEKIT_API_KEY"),
            "preserved": True,
            "message": "Voz atual preservada. Nao alterada nesta fase.",
        }
    })


@app.get("/tokyo/security/status")
async def security_status():
    return safe_response({
        "security": {
            "safe_mode": TOKYO_SAFE_MODE,
            "token_exposed": TOKYO_TOKEN_EXPOSED,
            "auth_enabled": env_bool("TOKYO_AUTH_ENABLED", True),
            "admin_configured": env_present("TOKYO_ADMIN_USER"),
            "session_secret_configured": env_present("TOKYO_SESSION_SECRET"),
            "safety_gate": env_bool("SAFETY_GATE_ENABLED", True),
            "confirm_write": env_bool("SAFETY_REQUIRE_CONFIRMATION_FOR_WRITE", True),
            "confirm_delete": env_bool("SAFETY_REQUIRE_CONFIRMATION_FOR_DELETE", True),
            "confirm_finance": env_bool("SAFETY_REQUIRE_CONFIRMATION_FOR_FINANCE", True),
            "confirm_stock": env_bool("SAFETY_REQUIRE_CONFIRMATION_FOR_STOCK", True),
            "confirm_price": env_bool("SAFETY_REQUIRE_CONFIRMATION_FOR_PRICE", True),
            "mask_secrets": env_bool("SAFETY_MASK_SECRETS_IN_LOGS", True),
        },
        "destructive_operations_blocked": True,
        "message": "Operacoes destrutivas bloqueadas. Seguranca preservada.",
    })


@app.get("/tokyo/business/status")
async def business_status():
    config = load_json_config("business.example.json")
    if config:
        return safe_response(config)
    return safe_response({"error": "Business config not found"})


@app.get("/tokyo/grupsbunny/status")
async def grupsbunny_status():
    return safe_response({
        "grupsbunny": {
            "name": "GrupsBunny",
            "type": "holding",
            "status": "active",
            "data_source": "pending_api",
            "companies": [
                {"id": "bunny_dreams", "name": "Bunny Dreams", "type": "retail"},
                {"id": "bunny_siberian", "name": "Bunny Siberian", "type": "systems_company"},
            ],
            "products": [
                {"id": "sistema_siberian", "name": "Sistema Siberian ERP", "type": "own_product"},
            ],
            "dashboard_status": "planned",
            "financial_status": "pending_api",
            "message": "Dados consolidados ainda nao conectados. Configure Sistema Siberian API ou importe planilhas autorizadas.",
        }
    })


@app.get("/tokyo/bunnydreams/status")
async def bunnydreams_status():
    return safe_response({
        "bunny_dreams": {
            "name": "Bunny Dreams",
            "type": "retail",
            "description": "Varejo - Loja de roupas e acessorios",
            "status": "active",
            "data_source": "pending_api",
            "units": [
                {
                    "id": "riverside",
                    "name": "Loja Riverside",
                    "type": "store",
                    "location": "Riverside",
                    "status": "active",
                    "data_source": "pending_api",
                },
                {
                    "id": "teresina",
                    "name": "Loja Teresina",
                    "type": "store",
                    "location": "Teresina",
                    "status": "active",
                    "data_source": "pending_api",
                },
            ],
            "dashboard_modules": [
                "daily_sales", "monthly_sales", "monthly_target", "target_gap",
                "average_ticket", "sales_calendar", "tasks", "stock",
                "critical_products", "financial_dre", "cash_flow", "break_even",
                "minimum_cash", "alerts", "tokyo_recommendations",
            ],
            "message": "Dados de vendas ainda nao conectados. Configure Sistema Siberian API.",
        }
    })


@app.get("/tokyo/bunnysiberian/status")
async def bunnysiberian_status():
    return safe_response({
        "bunny_siberian": {
            "name": "Bunny Siberian",
            "type": "systems_company",
            "description": "Empresa de sistemas - SaaS/ERP B2B",
            "business_model": {
                "type": "recurring_revenue",
                "products": ["sistema_siberian", "consulting", "implementation", "support"],
                "revenue_streams": ["mrr", "implementation_fees", "support_contracts"],
                "metrics": ["mrr", "churn_rate", "ltv", "cac", "arpu"],
            },
            "status": "active",
            "data_source": "pending_api",
            "dashboard_modules": [
                "overview", "recurring_revenue", "active_clients", "mrr",
                "churn", "support_tickets", "implementation_status",
                "sales_funnel", "sold_modules", "api_status", "siberian_erp_status",
            ],
            "message": "Dados da Bunny Siberian ainda nao conectados. Configure Bunny Siberian API.",
        }
    })


@app.get("/tokyo/finance/status")
async def finance_status():
    return safe_response({
        "finance": {
            "status": "planned",
            "data_source": "pending_api",
            "no_fake_data": True,
            "message": "Dados financeiros ainda nao conectados. Configure Sistema Siberian API ou importe planilhas autorizadas.",
            "modules_planned": [
                {"id": "dre", "name": "DRE", "status": "planned"},
                {"id": "cash_flow", "name": "Fluxo de Caixa", "status": "planned"},
                {"id": "break_even", "name": "Ponto de Equilibrio", "status": "planned"},
                {"id": "operational_cycle", "name": "Ciclo Financeiro", "status": "planned"},
                {"id": "minimum_cash", "name": "Caixa Minimo", "status": "planned"},
                {"id": "financial_dashboard", "name": "Dashboard Financeiro", "status": "planned"},
            ],
            "reference_spreadsheets": [
                "Modelo+de+DRE.xlsx",
                "Estrutura+de+DRE.xlsx",
                "Estrutura+de+Fluxo+de+Caixa.xlsx",
                "Ponto de Equilibrio.xlsx",
                "Ciclo Operaciona, Financeiro e Caixa Minimo.xlsx",
                "Ciclo Operaciona, Financeiro e Caixa Minimo (1).xlsx",
            ],
            "reference_status": "recognized_as_business_models",
            "future_upload": {
                "area": "Bunny Intelligence Bank > Planilhas Financeiras",
                "status": "upload_pending_parser_pending",
                "accepted_formats": ["xlsx", "csv", "ods"],
            },
        }
    })


@app.get("/tokyo/finance/models")
async def finance_models():
    config = load_json_config("finance_models.example.json")
    if config:
        return safe_response(config)
    return safe_response({"error": "Finance models config not found"})


@app.get("/tokyo/finance/references")
async def finance_references():
    return safe_response({
        "reference_spreadsheets": [
            {
                "file": "Modelo+de+DRE.xlsx",
                "model_id": "dre",
                "status": "reference_only",
                "message": "Usado como modelo de negocio, nao como dado real",
            },
            {
                "file": "Estrutura+de+DRE.xlsx",
                "model_id": "dre",
                "status": "reference_only",
                "message": "Usado como modelo de negocio, nao como dado real",
            },
            {
                "file": "Estrutura+de+Fluxo+de+Caixa.xlsx",
                "model_id": "cash_flow",
                "status": "reference_only",
                "message": "Usado como modelo de negocio, nao como dado real",
            },
            {
                "file": "Ponto de Equilibrio.xlsx",
                "model_id": "break_even",
                "status": "reference_only",
                "message": "Usado como modelo de negocio, nao como dado real",
            },
            {
                "file": "Ciclo Operaciona, Financeiro e Caixa Minimo.xlsx",
                "model_ids": ["operational_cycle", "minimum_cash"],
                "status": "reference_only",
                "message": "Usado como modelo de negocio, nao como dado real",
            },
            {
                "file": "Ciclo Operaciona, Financeiro e Caixa Minimo (1).xlsx",
                "model_ids": ["operational_cycle", "minimum_cash"],
                "status": "reference_only",
                "message": "Usado como modelo de negocio, nao como dado real",
            },
        ],
        "policy": {
            "no_data_alteration": True,
            "no_overwrite": True,
            "no_fake_values": True,
            "used_as_business_models_only": True,
        },
    })


@app.get("/tokyo/hardware/status")
async def hardware_status():
    return safe_response({
        "hardware_target": {
            "cpu": "Xeon 22 nucleos",
            "gpu": "2x RTX 3060 12GB",
            "ram": "64GB",
            "storage": ["1TB NVMe", "1TB SSD"],
            "platform": "ZimaOS",
            "uptime": "24/7",
        },
        "future_expansion": {
            "mac_mini_m5": {
                "role": "estacao premium/cliente/agente",
                "connector": "apple_macos_agent",
                "status": "planned",
            },
        },
    })


@app.get("/tokyo/update/status")
async def update_status():
    return safe_response({
        "update": {
            "current_version": "3.0.0-phase3a",
            "status": "phase3a_siberian_readonly_api",
            "upgrade_prepared": True,
            "message": "Phase 2 Read-Only Data Layer active. Finance engine, upload center, Siberian connector prepared.",
        }
    })


# ═══════════════════════════════════════════════════════════
# PHASE 2: FINANCE CALCULATION ENDPOINTS
# ═══════════════════════════════════════════════════════════

class DRERequest(BaseModel):
    gross_revenue: Optional[float] = None
    deductions: Optional[float] = None
    cogs: Optional[float] = None
    fixed_expenses: Optional[float] = None
    variable_expenses: Optional[float] = None
    source: str = "manual_input"
    scope: str = "grupsbunny"

class CashFlowRequest(BaseModel):
    opening_balance: Optional[float] = None
    inflows: Optional[float] = None
    outflows: Optional[float] = None
    accounts_receivable: Optional[float] = None
    accounts_payable: Optional[float] = None
    source: str = "manual_input"
    scope: str = "grupsbunny"

class BreakEvenRequest(BaseModel):
    fixed_costs: Optional[float] = None
    contribution_margin_percent: Optional[float] = None
    target_profit: Optional[float] = None
    source: str = "manual_input"
    scope: str = "grupsbunny"

class OperationalCycleRequest(BaseModel):
    average_inventory_days: Optional[float] = None
    average_receivable_days: Optional[float] = None
    source: str = "manual_input"
    scope: str = "grupsbunny"

class FinancialCycleRequest(BaseModel):
    average_inventory_days: Optional[float] = None
    average_receivable_days: Optional[float] = None
    average_payable_days: Optional[float] = None
    source: str = "manual_input"
    scope: str = "grupsbunny"

class MinimumCashRequest(BaseModel):
    daily_cash_need: Optional[float] = None
    financial_cycle_days: Optional[float] = None
    safety_days: Optional[float] = None
    source: str = "manual_input"
    scope: str = "grupsbunny"


@app.post("/tokyo/finance/calculate/dre")
async def finance_calculate_dre(req: DRERequest):
    audit_log("finance_calculation_requested", {"module": "dre", "scope": req.scope, "source": req.source})
    result = calculate_dre(
        gross_revenue=req.gross_revenue,
        deductions=req.deductions,
        cogs=req.cogs,
        fixed_expenses=req.fixed_expenses,
        variable_expenses=req.variable_expenses,
        source=req.source,
        scope=req.scope,
    )
    audit_log("finance_calculation_completed", {"module": "dre", "success": result["success"], "warnings": result["warnings"]})
    return safe_response(result)


@app.post("/tokyo/finance/calculate/cash-flow")
async def finance_calculate_cash_flow(req: CashFlowRequest):
    audit_log("finance_calculation_requested", {"module": "cash_flow", "scope": req.scope, "source": req.source})
    result = calculate_cash_flow(
        opening_balance=req.opening_balance,
        inflows=req.inflows,
        outflows=req.outflows,
        accounts_receivable=req.accounts_receivable,
        accounts_payable=req.accounts_payable,
        source=req.source,
        scope=req.scope,
    )
    audit_log("finance_calculation_completed", {"module": "cash_flow", "success": result["success"], "warnings": result["warnings"]})
    return safe_response(result)


@app.post("/tokyo/finance/calculate/break-even")
async def finance_calculate_break_even(req: BreakEvenRequest):
    audit_log("finance_calculation_requested", {"module": "break_even", "scope": req.scope, "source": req.source})
    result = calculate_break_even(
        fixed_costs=req.fixed_costs,
        contribution_margin_percent=req.contribution_margin_percent,
        target_profit=req.target_profit,
        source=req.source,
        scope=req.scope,
    )
    audit_log("finance_calculation_completed", {"module": "break_even", "success": result["success"], "warnings": result["warnings"]})
    return safe_response(result)


@app.post("/tokyo/finance/calculate/operational-cycle")
async def finance_calculate_operational_cycle(req: OperationalCycleRequest):
    audit_log("finance_calculation_requested", {"module": "operational_cycle", "scope": req.scope, "source": req.source})
    result = calculate_operational_cycle(
        average_inventory_days=req.average_inventory_days,
        average_receivable_days=req.average_receivable_days,
        source=req.source,
        scope=req.scope,
    )
    audit_log("finance_calculation_completed", {"module": "operational_cycle", "success": result["success"], "warnings": result["warnings"]})
    return safe_response(result)


@app.post("/tokyo/finance/calculate/financial-cycle")
async def finance_calculate_financial_cycle(req: FinancialCycleRequest):
    audit_log("finance_calculation_requested", {"module": "financial_cycle", "scope": req.scope, "source": req.source})
    result = calculate_financial_cycle(
        average_inventory_days=req.average_inventory_days,
        average_receivable_days=req.average_receivable_days,
        average_payable_days=req.average_payable_days,
        source=req.source,
        scope=req.scope,
    )
    audit_log("finance_calculation_completed", {"module": "financial_cycle", "success": result["success"], "warnings": result["warnings"]})
    return safe_response(result)


@app.post("/tokyo/finance/calculate/minimum-cash")
async def finance_calculate_minimum_cash(req: MinimumCashRequest):
    audit_log("finance_calculation_requested", {"module": "minimum_cash", "scope": req.scope, "source": req.source})
    result = calculate_minimum_cash(
        daily_cash_need=req.daily_cash_need,
        financial_cycle_days=req.financial_cycle_days,
        safety_days=req.safety_days,
        source=req.source,
        scope=req.scope,
    )
    audit_log("finance_calculation_completed", {"module": "minimum_cash", "success": result["success"], "warnings": result["warnings"]})
    return safe_response(result)


# ═══════════════════════════════════════════════════════════
# PHASE 2: SPREADSHEET UPLOAD CENTER
# ═══════════════════════════════════════════════════════════

UPLOAD_DIR = Path(os.getenv("TOKYO_DATA_DIR", "/opt/tokyo/Tokyo painel/data")) / "uploads" / "finance"
IMPORT_DIR = Path(os.getenv("TOKYO_DATA_DIR", "/opt/tokyo/Tokyo painel/data")) / "imported" / "finance"


@app.get("/tokyo/finance/uploads/status")
async def finance_uploads_status():
    return safe_response({
        "upload_center": "Bunny Intelligence Bank > Planilhas Financeiras",
        "status": "planned",
        "upload_enabled": False,
        "reason": "upload_parser_pending",
        "rules": {
            "never_overwrite_original": True,
            "save_copy_with_timestamp": True,
            "register_metadata": True,
            "no_macro_execution": True,
            "no_formula_trust_without_validation": True,
            "accepted_formats": [".xlsx", ".csv"],
            "blocked_formats": [".xlsm", ".exe", ".zip", ".sh", ".py"],
        },
        "directories": {
            "uploads": str(UPLOAD_DIR),
            "imported": str(IMPORT_DIR),
        },
        "token_exposed": False,
    })


@app.get("/tokyo/finance/uploads/registry")
async def finance_uploads_registry():
    imports = []
    if IMPORT_DIR.exists():
        for f in sorted(IMPORT_DIR.glob("*.json")):
            try:
                imports.append(json.loads(f.read_text()))
            except Exception:
                pass
    return safe_response({
        "imports": imports,
        "count": len(imports),
        "status": "planned",
        "message": "Upload center prepared. Nenhum arquivo importado ainda.",
        "token_exposed": False,
    })


class UploadValidateRequest(BaseModel):
    filename: str
    file_size: Optional[int] = None


@app.post("/tokyo/finance/uploads/validate")
async def finance_uploads_validate(req: UploadValidateRequest):
    filename = req.filename.lower()
    blocked = [".xlsm", ".exe", ".zip", ".sh", ".py", ".bat", ".cmd", ".ps1"]
    blocked_reason = None
    for ext in blocked:
        if filename.endswith(ext):
            blocked_reason = f"Formato bloqueado: {ext}. Macros/executaveis nao sao aceitos."
            break

    accepted = [".xlsx", ".csv"]
    accepted_ext = any(filename.endswith(ext) for ext in accepted)

    audit_log("spreadsheet_validated" if accepted_ext else "spreadsheet_blocked", {
        "filename": filename,
        "accepted": accepted_ext,
        "blocked_reason": blocked_reason,
    })

    return safe_response({
        "valid": accepted_ext and not blocked_reason,
        "filename": req.filename,
        "accepted": accepted_ext,
        "blocked_reason": blocked_reason,
        "message": "Arquivo valido para upload futuro." if accepted_ext and not blocked_reason else ("Arquivo bloqueado: " + blocked_reason),
    })


# ═══════════════════════════════════════════════════════════
# PHASE 2: BUSINESS DATA LAYER
# ═══════════════════════════════════════════════════════════

SCOPES = [
    {"id": "grupsbunny", "name": "GrupsBunny", "type": "holding", "status": "active", "data_source": "pending_api", "validation_status": "pending_validation"},
    {"id": "bunny_dreams", "name": "Bunny Dreams", "type": "retail", "status": "active", "data_source": "pending_api", "validation_status": "pending_validation"},
    {"id": "riverside", "name": "Loja Riverside", "type": "store", "status": "active", "data_source": "pending_api", "validation_status": "pending_validation"},
    {"id": "teresina", "name": "Loja Teresina", "type": "store", "status": "active", "data_source": "pending_api", "validation_status": "pending_validation"},
    {"id": "bunny_siberian", "name": "Bunny Siberian", "type": "systems_company", "status": "active", "data_source": "pending_api", "validation_status": "pending_validation"},
    {"id": "sistema_siberian", "name": "Sistema Siberian ERP", "type": "product", "status": "planned", "data_source": "pending_api", "validation_status": "pending_validation"},
]

DATA_SOURCES = [
    {"id": "pending_api", "type": "api", "status": "not_configured", "mode": "read_only", "description": "Sistema Siberian API — nao configurada"},
    {"id": "manual_input", "type": "manual", "status": "available", "mode": "read_only", "description": "Entrada manual de dados (pending_validation)"},
    {"id": "spreadsheet_upload", "type": "file", "status": "planned", "mode": "read_only", "description": "Upload de planilhas (futuro)"},
    {"id": "spreadsheet_reference", "type": "file", "status": "recognized", "mode": "reference_only", "description": "Planilhas de referencia (modelos estruturais)"},
]


@app.get("/tokyo/business/data-sources")
async def business_data_sources():
    return safe_response({
        "data_sources": DATA_SOURCES,
        "active_sources": [ds for ds in DATA_SOURCES if ds["status"] in ("available", "active")],
        "token_exposed": False,
    })


@app.get("/tokyo/business/scopes")
async def business_scopes():
    return safe_response({
        "scopes": SCOPES,
        "count": len(SCOPES),
        "token_exposed": False,
    })


@app.get("/tokyo/business/readiness")
async def business_readiness():
    ready = any(s["data_source"] not in ("pending_api", "not_configured") for s in SCOPES)
    return safe_response({
        "ready": ready,
        "status": "pending_data" if not ready else "data_available",
        "message": "Dados empresariais ainda nao conectados. Configure Sistema Siberian API ou importe planilhas autorizadas." if not ready else "Alguns dados empresariais disponiveis.",
        "scopes_summary": {s["id"]: {"data_source": s["data_source"], "validation_status": s["validation_status"]} for s in SCOPES},
        "token_exposed": False,
    })


# ═══════════════════════════════════════════════════════════
# PHASE 2: AUDIT LOG ENDPOINT
# ═══════════════════════════════════════════════════════════

@app.get("/tokyo/finance/audit")
async def finance_audit_log():
    from finance_engine.audit import AUDIT_FILE
    entries = []
    if AUDIT_FILE.exists():
        try:
            for line in AUDIT_FILE.read_text().strip().split("\n"):
                if line:
                    entries.append(json.loads(line))
        except Exception:
            pass
    return safe_response({
        "audit_log": "phase_2_finance_data_layer.jsonl",
        "entries": entries[-50:],
        "total": len(entries),
        "token_exposed": False,
    })


# ═══════════════════════════════════════════════════════════
# PHASE 3B: VOICE CONTROL CENTER
# ═══════════════════════════════════════════════════════════

@app.get("/tokyo/voice/capabilities")
async def voice_capabilities():
    return safe_response({
        "provider": "LiveKit + Google Gemini Realtime",
        "voice_name": "Charon",
        "capabilities": ["realtime_conversation", "memory", "noise_cancellation", "video"],
        "activation_modes": {
            "push_to_talk": "planned",
            "wake_word": {"status": "planned", "word": "Tokyo"},
            "continuous": "planned",
            "command_preview": "active",
        },
        "configured": env_present("LIVEKIT_URL"),
        "token_exposed": False,
    })


@app.get("/tokyo/voice/activation/status")
async def voice_activation_status():
    return safe_response({
        "activation": {
            "mode": "push_to_talk_planned",
            "wake_word": "Tokyo",
            "wake_word_status": "planned",
            "commands_executable": False,
            "reason": "Voice commands are preview-only in this phase. No real actions executed.",
        },
        "commands_available": 8,
        "commands": [
            {"command": "Tokyo, abrir dashboard", "target": "/ui", "status": "planned"},
            {"command": "Tokyo, abrir MCP", "target": "/ui#mcp", "status": "planned"},
            {"command": "Tokyo, abrir financeiro", "target": "/ui#finance", "status": "planned"},
            {"command": "Tokyo, status do sistema", "target": "/tokyo/system/health", "status": "planned"},
            {"command": "Tokyo, abrir API Hub", "target": "/ui#api-hub", "status": "planned"},
        ],
        "token_exposed": False,
    })


class VoicePreviewRequest(BaseModel):
    command: str

@app.post("/tokyo/voice/activation/preview")
async def voice_activation_preview(req: VoicePreviewRequest):
    available_commands = [
        {"command": "Tokyo, abrir dashboard", "target": "/ui"},
        {"command": "Tokyo, abrir MCP", "target": "/ui#mcp"},
        {"command": "Tokyo, abrir financeiro", "target": "/ui#finance"},
        {"command": "Tokyo, abrir setup", "target": "/setup"},
        {"command": "Tokyo, status do sistema", "target": "/tokyo/system/health"},
        {"command": "Tokyo, abrir API Hub", "target": "/ui#api-hub"},
        {"command": "Tokyo, mostrar Bunny Dreams", "target": "/ui#bunny-dreams"},
        {"command": "Tokyo, abrir voz", "target": "/ui#voice"},
    ]
    matched = [c for c in available_commands if c["command"] == req.command]
    if matched:
        target = matched[0]["target"]
        return safe_response({
            "recognized": True,
            "command": req.command,
            "target": target,
            "action": "preview_only",
            "executed": False,
            "message": f"Command '{req.command}' recognized. Preview only - no action executed.",
        })
    available_str = ", ".join([c["command"] for c in available_commands])
    return safe_response({
        "recognized": False,
        "command": req.command,
        "action": "preview_only",
        "executed": False,
        "message": f"Command not recognized. Available: {available_str}",
    })


@app.post("/tokyo/voice/activation/test-command")
async def voice_test_command(req: VoicePreviewRequest):
    return await voice_activation_preview(req)


# ═══════════════════════════════════════════════════════════
# PHASE 3B: MCP PANEL
# ═══════════════════════════════════════════════════════════

@app.get("/tokyo/mcp/servers")
async def mcp_servers():
    config = load_json_config("mcp_servers.example.json")
    if config:
        return safe_response(config)
    return safe_response({
        "mcp_servers": [],
        "mode": "optional",
        "required": False,
        "token_exposed": False,
    })


@app.get("/tokyo/mcp/capabilities")
async def mcp_capabilities():
    return safe_response({
        "mcp": {
            "enabled": env_bool("MCP_ENABLED"),
            "required": False,
            "status": "configured" if env_present("MCP_BASE_URL") else "not_configured",
            "mode": "optional",
            "safe_mode": True,
            "capabilities": ["tools", "context", "servers"],
            "servers_registered": 5,
            "servers_active": 0,
        },
        "token_exposed": False,
    })


@app.get("/tokyo/mcp/tools")
async def mcp_tools():
    return safe_response({
        "tools": [],
        "status": "not_configured",
        "message": "MCP nao configurado. Ferramentas indisponiveis.",
        "token_exposed": False,
    })


class MCPTestRequest(BaseModel):
    server_id: Optional[str] = None
    base_url: Optional[str] = None

@app.post("/tokyo/mcp/test-connection")
async def mcp_test_connection(req: MCPTestRequest):
    return safe_response({
        "tested": False,
        "reason": "MCP test-connection is a preview placeholder. Configure MCP_BASE_URL in .env to enable.",
        "token_exposed": False,
    })


# ═══════════════════════════════════════════════════════════
# PHASE 3B: API HUB / EXTERNAL TOOLS
# ═══════════════════════════════════════════════════════════

@app.get("/tokyo/api-hub/connectors")
async def api_hub_connectors():
    config = load_json_config("external_tools.example.json")
    if config:
        return safe_response(config)
    return safe_response({"external_tools": [], "token_exposed": False})


@app.get("/tokyo/api-hub/tools")
async def api_hub_tools():
    config = load_json_config("external_tools.example.json")
    if config:
        tools_summary = [
            {"id": t["id"], "name": t["name"], "status": t["status"], "required": t["required"], "mode": t["mode"], "safe_mode": t["safe_mode"]}
            for t in config.get("external_tools", [])
        ]
        return safe_response({"tools": tools_summary, "total": len(tools_summary), "all_required_false": True, "token_exposed": False})
    return safe_response({"tools": [], "token_exposed": False})


@app.get("/tokyo/api-hub/readiness")
async def api_hub_readiness():
    return safe_response({
        "ready": False,
        "status": "not_configured",
        "message": "API Hub configurado. Ferramentas externas planejadas mas nao instaladas. Conecte ferramentas via ZimaOS/Docker quando disponivel.",
        "external_write_enabled": False,
        "token_exposed": False,
    })


class APITestRequest(BaseModel):
    connector_id: str

@app.post("/tokyo/api-hub/test-connector")
async def api_hub_test_connector(req: APITestRequest):
    return safe_response({
        "tested": False,
        "connector_id": req.connector_id,
        "reason": f"Teste de conector '{req.connector_id}' e um placeholder. Configure as variaveis de ambiente correspondentes para ativar.",
        "token_exposed": False,
    })


# ═══════════════════════════════════════════════════════════
# PHASE 3B: ZIMAOS READY CENTER
# ═══════════════════════════════════════════════════════════

@app.get("/tokyo/zimaos/status")
async def zimaos_status():
    import shutil
    docker_installed = shutil.which("docker") is not None
    compose_file = BASE_DIR / "docker-compose.yml"
    dockerfile = BASE_DIR / "Dockerfile"
    return safe_response({
        "zimaos": {
            "app_port": 8788,
            "data_path": "/DATA/AppData/tokyoos",
            "volume": "/DATA/AppData/tokyoos:/data/tokyo",
            "network_mode": "bridge",
            "restart": "unless-stopped",
            "store_app_id": "tokyoos",
            "scheme": "http",
            "index": "/ui",
            "x_casaos": True,
        },
        "docker": {
            "installed": docker_installed,
            "compose_file_exists": compose_file.exists(),
            "dockerfile_exists": dockerfile.exists(),
            "healthcheck": True,
        },
        "token_exposed": False,
    })


@app.get("/tokyo/zimaos/readiness")
async def zimaos_readiness():
    import shutil
    docker_installed = shutil.which("docker") is not None
    compose_file = BASE_DIR / "docker-compose.yml"
    issues = []
    if not docker_installed:
        issues.append("Docker not installed on this host")
    if not compose_file.exists():
        issues.append("docker-compose.yml not found")
    return safe_response({
        "ready": docker_installed and compose_file.exists(),
        "docker_installed": docker_installed,
        "compose_exists": compose_file.exists(),
        "issues": issues,
        "next_step": "docker compose up -d" if docker_installed and compose_file.exists() else "Install Docker and ensure docker-compose.yml is present",
        "token_exposed": False,
    })


@app.get("/tokyo/zimaos/docker-status")
async def zimaos_docker_status():
    import shutil
    docker_installed = shutil.which("docker") is not None
    return safe_response({
        "docker_installed": docker_installed,
        "docker_compose_available": (BASE_DIR / "docker-compose.yml").exists(),
        "dockerfile_available": (BASE_DIR / "Dockerfile").exists(),
        "healthcheck_configured": True,
        "token_exposed": False,
    })


@app.get("/tokyo/zimaos/install-checklist")
async def zimaos_install_checklist():
    return safe_response({
        "checklist": [
            {"step": "app.py running", "status": "done", "detail": "FastAPI backend active"},
            {"step": "Dockerfile", "status": "done" if (BASE_DIR / "Dockerfile").exists() else "pending", "detail": "Container build definition"},
            {"step": "docker-compose.yml", "status": "done" if (BASE_DIR / "docker-compose.yml").exists() else "pending", "detail": "Orchestration + x-casaos labels"},
            {"step": "x-casaos labels", "status": "done", "detail": "ZimaOS app store metadata"},
            {"step": "Healthcheck", "status": "done", "detail": "/tokyo/system/health"},
            {"step": "Data volumes", "status": "done", "detail": "/DATA/AppData/tokyoos:/data/tokyo"},
            {"step": "External tools planned", "status": "done", "detail": "Hermes, MCP, Ollama, OpenWebUI, etc."},
            {"step": "Environment file", "status": "done" if env_present("TOKYO_ENV") else "pending", "detail": ".env configuration"},
        ],
        "ready": True,
        "token_exposed": False,
    })


# ═══════════════════════════════════════════════════════════
# PHASE 3B: INSTALL MODE (SETUP PAGE)
# ═══════════════════════════════════════════════════════════

@app.get("/setup", response_class=HTMLResponse)
async def serve_setup():
    ui_file = INTERFACE_DIR / "index.html"
    if ui_file.exists():
        content = ui_file.read_text(encoding="utf-8")
        content = content.replace('class="nav-tab active" onclick="document.querySelectorAll', 'class="nav-tab" onclick="document.querySelectorAll')
        content = content.replace('id="overview" class="tab-content"', 'id="overview" class="tab-content" style="display:none"')
        content = content.replace('id="setup-page" style="display:none"', 'id="setup-page" style="display:block"')
        if '<div id="setup-page"' not in content:
            content = content.replace('</div>\n\n</div>\n\n</body>', '</div>\n\n<div id="setup-page" style="display:block;max-width:900px;margin:0 auto"><h2 style="color:var(--accent-glow);margin-bottom:16px">Setup Wizard</h2><p style="color:var(--text-secondary);margin-bottom:24px">TokyoOS Installation — Welcome to your AI Hub</p><div class="grid" id="setup-steps"></div></div>\n\n</div>\n\n</body>')
        return HTMLResponse(content=content)
    return HTMLResponse(content="<h1>TokyoOS Setup</h1>", status_code=404)


# ═══════════════════════════════════════════════════════════
# PHASE 3C: ZIMAOS DEPLOY READINESS (extended)
# ═══════════════════════════════════════════════════════════

@app.get("/tokyo/zimaos/volumes")
async def zimaos_volumes():
    return safe_response({
        "volumes": [
            {"host": "/DATA/AppData/tokyoos", "container": "/data/tokyo", "mode": "rw", "status": "configured"},
            {"container": "/data/tokyo/tools", "host": "/DATA/AppData/tokyoos/tools", "status": "planned"},
            {"container": "/data/tokyo/connectors", "host": "/DATA/AppData/tokyoos/connectors", "status": "planned"},
            {"container": "/data/tokyo/mcp", "host": "/DATA/AppData/tokyoos/mcp", "status": "planned"},
            {"container": "/data/tokyo/logs", "host": "/DATA/AppData/tokyoos/logs", "status": "configured"},
            {"container": "/data/tokyo/uploads", "host": "/DATA/AppData/tokyoos/uploads", "status": "planned"},
            {"container": "/data/tokyo/cache", "host": "/DATA/AppData/tokyoos/cache", "status": "planned"},
            {"container": "/data/tokyo/config", "host": "/DATA/AppData/tokyoos/config", "status": "planned"},
        ],
        "token_exposed": False,
    })


@app.get("/tokyo/zimaos/ports")
async def zimaos_ports():
    return safe_response({
        "ports": [
            {"container": 8788, "host": 8788, "protocol": "tcp", "description": "TokyoOS HTTP API + UI"},
        ],
        "external_tools_planned_ports": {
            "hermes": 8791, "mcp": 8789, "ollama": 11434, "openwebui": 3000, "n8n": 5678,
        },
        "token_exposed": False,
    })


@app.get("/tokyo/zimaos/app-metadata")
async def zimaos_app_metadata():
    return safe_response({
        "app": {
            "title": "TokyoOS",
            "developer": "GrupsBunny",
            "author": "GrupsBunny",
            "category": "Utilities",
            "tagline": "Tokyo IA — GrupsBunny AI Hub with Voice, Dashboard & ERP",
            "description": "Assistente de IA com voz, dashboard empresarial, integracao ERP, MCP opcional e preparacao para ferramentas externas no ZimaOS.",
            "version": "3.2.0-phase3c",
            "store_app_id": "tokyoos",
            "scheme": "http",
            "port_map": "8788",
            "index": "/ui",
            "icon": "placeholder",
        },
        "docker": {
            "image": "tokyoos:latest",
            "build": "Dockerfile",
            "restart": "unless-stopped",
            "volumes": ["/DATA/AppData/tokyoos:/data/tokyo"],
            "ports": ["8788:8788"],
            "healthcheck": "/tokyo/system/health",
        },
        "token_exposed": False,
    })


# ═══════════════════════════════════════════════════════════
# PHASE 3C: TOOLS DIRECTORY MODEL
# ═══════════════════════════════════════════════════════════

@app.get("/tokyo/tools/directories")
async def tools_directories():
    data_dir = Path(os.getenv("TOKYO_DATA_DIR", "/data/tokyo"))
    dirs = ["tools", "connectors", "mcp", "logs", "uploads", "cache", "config", "releases"]
    result = {}
    for d in dirs:
        p = data_dir / d
        result[d] = {"path": str(p), "exists": p.exists()}
    return safe_response({
        "data_dir": str(data_dir),
        "directories": result,
        "all_exist": all(v["exists"] for v in result.values()),
        "mode": "planned",
        "message": "Diretorios criados conforme disponivel. Alguns podem ser criados no primeiro deploy.",
        "token_exposed": False,
    })


# ═══════════════════════════════════════════════════════════
# PHASE 3C: EXTERNAL TOOLS ENV CHECKLIST
# ═══════════════════════════════════════════════════════════

@app.get("/tokyo/tools/env-checklist")
async def tools_env_checklist():
    tools = [
        {"id": "hermes", "env": ["HERMES_ENABLED=false", "HERMES_BASE_URL=", "HERMES_API_KEY="], "port": 8791, "required": False},
        {"id": "mcp", "env": ["MCP_ENABLED=false", "MCP_BASE_URL=", "MCP_API_KEY="], "port": 8789, "required": False},
        {"id": "ollama", "env": ["OLLAMA_ENABLED=false", "OLLAMA_BASE_URL=http://host.docker.internal:11434"], "port": 11434, "required": False},
        {"id": "openwebui", "env": ["OPENWEBUI_ENABLED=false", "OPENWEBUI_BASE_URL=", "OPENWEBUI_API_KEY="], "port": 3000, "required": False},
        {"id": "browser_use", "env": ["BROWSER_USE_ENABLED=false", "BROWSER_USE_BASE_URL=", "BROWSER_USE_API_KEY="], "required": False},
        {"id": "firecrawl", "env": ["FIRECRAWL_ENABLED=false", "FIRECRAWL_BASE_URL=", "FIRECRAWL_API_KEY="], "required": False},
        {"id": "n8n", "env": ["N8N_ENABLED=false", "N8N_BASE_URL=", "N8N_API_KEY="], "port": 5678, "required": False},
        {"id": "openclaw", "env": ["OPENCLAW_ENABLED=false", "OPENCLAW_BASE_URL=", "OPENCLAW_API_KEY="], "required": False},
        {"id": "apple_agent", "env": ["APPLE_AGENT_ENABLED=false", "APPLE_AGENT_BASE_URL=", "APPLE_AGENT_API_KEY="], "required": False, "status": "planned"},
        {"id": "telegram", "env": ["TELEGRAM_ENABLED=false", "TELEGRAM_BOT_TOKEN="], "required": False},
        {"id": "whatsapp", "env": ["WHATSAPP_ENABLED=false", "WHATSAPP_API_URL=", "WHATSAPP_API_TOKEN="], "required": False},
    ]
    return safe_response({"tools": tools, "total": len(tools), "auto_install_enabled": False, "token_exposed": False})


if __name__ == "__main__":
    import uvicorn
    logger.info(f"TokyoOS starting on {TOKYO_HOST}:{TOKYO_HTTP_PORT}")
    uvicorn.run(app, host=TOKYO_HOST, port=TOKYO_HTTP_PORT, log_level="info")
